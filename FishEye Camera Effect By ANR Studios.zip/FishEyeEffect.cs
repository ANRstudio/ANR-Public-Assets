﻿using UnityEngine;

[ExecuteInEditMode]
[RequireComponent(typeof(Camera))]
public class FishEyeEffect : MonoBehaviour
{
    [Range(-2f, 2f), Tooltip("Negative → Pinch Inward; Positive → Bulge Outward")]
    public float strength = -0.5f;

    private Material mat;
    public Shader fishEyeShader;

    void Awake()
    {
        if (fishEyeShader == null)
            fishEyeShader = Shader.Find("Custom/FishEye");
        mat = new Material(fishEyeShader);
    }

    void OnRenderImage(RenderTexture src, RenderTexture dest)
    {
        if (mat != null)
        {
            mat.SetFloat("_Strength", strength);
            Graphics.Blit(src, dest, mat);
        }
        else
        {
            Graphics.Blit(src, dest);
        }
    }
}
